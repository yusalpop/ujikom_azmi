<?php
include("css.php");
session_start();
if (!isset($_SESSION['nama'])) {
  header('location:../index2.php');
}
if ($_SESSION['level'] != "admin") {
  header('location:../index2.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<title>Admin</title>

<body id="page-top">
  <div id="wrapper">
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-keyboard"></i>
        </div>

        <div class="sidebar-brand-text mx-3">Pengaduan Masyarakat<sup></sup></div>
      </a>
      <hr class="sidebar-divider my-0">
      <li class="nav-item">
        <a class="nav-link" href="admin.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard Admin</span></a>
      </li>

      <hr class="sidebar-divider">
      <div class="sidebar-heading">
        Menu
      </div>
      <li class="nav-item">
        <a class="nav-link" href="?url=verifikasi_pengaduan">
          <i class="fas fa-check"></i>
          <span>Laporan Terverfikasi</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true"
          aria-controls="collapseTwo">
          <i class="fas fa-fw fa-file"></i>
          <span>Data</span>
        </a>

        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Data:</h6>
            <a class="collapse-item" href="?url=lihat_petugas">Data Petugas</a>
            <a class="collapse-item" href="?url=lihat_laporan">Data Laporan</a>
            <a class="collapse-item" href="?url=lihat_masyarakat">Data Masyarakat</a>
            <a class="collapse-item" href="?url=lihat_tanggapan">Data Tanggapan</a>
          </div>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true"
          aria-controls="collapseThree">
          <i class="fas fa-fw fa-print"></i>
          <span>Laporan</span>
        </a>

        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Laporan:</h6>
            <a class="collapse-item" href="?url=preview_petugas">Laporan Petugas</a>
            <a class="collapse-item" href="?url=preview_pengaduan">Laporan Pengaduan</a>
            <a class="collapse-item" href="?url=preview_masyarakat">Laporan Masyarakat</a>
            <a class="collapse-item" href="?url=preview_tanggapan">Laporan Tanggapan</a>
          </div>
        </div>
      </li>

      <hr class="sidebar-divider d-none d-md-block">
      <li class="nav-item">
        <a class="nav-link" href="../logout.php">
          <i class="fas fa-sign-out-alt"></i>
          <span>Keluar</span></a>
      </li>

      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>
    </ul>

    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <h1>Aplikasi Pelaporan Pengaduan Masyarakat</h1>
        </nav>

        <div class="container-fluid">
          <?php
          include 'halaman_admin.php'
            ?>
        </div>
      </div>

      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Uji Kompetensi R.Analia 2023</span>
          </div>
        </div>
      </footer>
    </div>
  </div>

  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

</body>

</html>