<?php
session_start();
include("css.php");
?>

<!DOCTYPE html>
<html lang="en">

<body id="page-top">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">

        </div>
        <div class="card-body">

            <h3 class="m-0 font-weight-bold text-secondary" align="center">UJI KOMPETENSI SMK SANGKURIANG 1 CIMAHI</h3>
            <h4 class="m-0 font-weight-bold text-secondary" align="center">REKAYASA PERANGKAT LUNAK</h4>
            <h6 class="m-0 font-weight-bold text-secondary" align="center">TAHUN AJARAN 2022/2023</h6>
            <br><br>
            <hr>
            <h4 class="m-0 font-weight-bold text-secondary" align="center">Laporan Data Masyarakat</h4>
            <br><br>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                    <tr>
                        <th>ID Petugas</th>
                        <th>Nama Petugas</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Telp</th>
                    </tr>

                    <?php
                    require '../koneksi.php';
                    $sql = mysqli_query($koneksi, "SELECT * FROM masyarakat");
                    while ($data = mysqli_fetch_array($sql)) {

                        ?>
                        <tbody>
                            <tr>
                                <td>
                                    <?php echo $data['nik']; ?>
                                </td>
                                <td>
                                    <?php echo $data['nama']; ?>
                                </td>
                                <td>
                                    <?php echo $data['username']; ?>
                                </td>
                                <td>
                                    <?php echo $data['password']; ?>
                                </td>
                                <td>
                                    <?php echo $data['telp']; ?>
                                </td>
                        </tbody>
                    <?php } ?>
                </table>
                <br>
                <br>
            </div>
            <h6 class="m-0 font-weight-bold text-primary" align="right">Cimahi,
                <?php echo date('d m Y'); ?>
            </h6>
            <h6 class="m-0 font-weight-bold text-primary" align="right">Petugas,</h6>
            <br><br><br><br>
            <h6 class="m-0 font-weight-bold text-primary" align="right">
                <?php echo $_SESSION['nama']; ?>
            </h6>
        </div>
    </div>
    </div>
    </div>

    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
            </div>
        </div>
    </footer>
    </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


</body>

</html>