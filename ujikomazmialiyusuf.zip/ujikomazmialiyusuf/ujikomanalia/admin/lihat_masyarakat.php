<?php
include("css.php");
?>

<!DOCTYPE html>
<html lang="en">

<body id="page-top">

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Masyarakat</h6>
        </div>
        <div class="card-body">

            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Telp</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <?php
                    require '../koneksi.php';
                    $sql = mysqli_query($koneksi, "SELECT * FROM masyarakat");
                    while ($data = mysqli_fetch_array($sql)) {

                        ?>
                        <tbody>
                            <tr>
                                <td>
                                    <?php echo $data['nik']; ?>
                                </td>
                                <td>
                                    <?php echo $data['nama']; ?>
                                </td>
                                <td>
                                    <?php echo $data['username']; ?>
                                </td>
                                <td>
                                    <?php echo $data['password']; ?>
                                </td>
                                <td>
                                    <?php echo $data['telp']; ?>
                                </td>
                                <td>
                                    </a>
                                    <a href="delete_masyarakat.php?nik=<?php echo $data['nik']; ?>"
                                        class="btn btn-danger btn-circle" onclick="return confirm('Hapus Data?')">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                        </tbody>
                    <?php } ?>
                </table>
            </div>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

</body>

</html>